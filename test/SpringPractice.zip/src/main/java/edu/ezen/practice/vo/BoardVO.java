package edu.ezen.practice.vo;

public class BoardVO {

}
